﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StartUp
{
    internal class Person
    {
    }
}
